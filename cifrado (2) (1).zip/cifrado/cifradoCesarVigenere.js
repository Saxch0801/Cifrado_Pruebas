// Archivo: cifradoCesarVigenere.js

// Función para mostrar el alfabeto
function mostrarAlfabeto() {
    const alfabeto = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    console.log('Alfabeto: ' + alfabeto);
    return alfabeto;
}

// Cifrado César
function cifradoCesar(texto, desplazamiento) {
    console.log(`Cifrando con César: "${texto}" con desplazamiento ${desplazamiento}`);
    const alfabeto = mostrarAlfabeto();
    let resultado = '';

    for (let i = 0; i < texto.length; i++) {
        let char = texto[i];

        if (char >= 'A' && char <= 'Z') {
            let index = (alfabeto.indexOf(char) + desplazamiento) % 26;
            resultado += alfabeto[index];
        } else {
            resultado += char;
        }
    }
    console.log('Resultado cifrado: ' + resultado);
    return resultado;
}

// Descifrado César
function descifradoCesar(texto, desplazamiento) {
    console.log(`Descifrando con César: "${texto}" con desplazamiento ${desplazamiento}`);
    const alfabeto = mostrarAlfabeto();
    let resultado = '';

    for (let i = 0; i < texto.length; i++) {
        let char = texto[i];

        if (char >= 'A' && char <= 'Z') {
            let index = (alfabeto.indexOf(char) - desplazamiento + 26) % 26;
            resultado += alfabeto[index];
        } else {
            resultado += char;
        }
    }
    console.log('Resultado descifrado: ' + resultado);
    return resultado;
}

// Generar la matriz de Vigenère
function generarMatrizVigenere() {
    const alfabeto = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let matriz = [];

    for (let i = 0; i < 26; i++) {
        matriz[i] = [];
        for (let j = 0; j < 26; j++) {
            matriz[i][j] = alfabeto[(i + j) % 26];
        }
    }

    console.log('Matriz de Vigenère:');
    console.table(matriz);
    return matriz;
}

// Cifrado Vigenère
function cifradoVigenere(texto, clave) {
    console.log(`Cifrando con Vigenère: "${texto}" con clave "${clave}"`);
    const alfabeto = mostrarAlfabeto();
    const matriz = generarMatrizVigenere();
    let resultado = '';

    for (let i = 0, j = 0; i < texto.length; i++) {
        let char = texto[i];

        if (char >= 'A' && char <= 'Z') {
            let row = alfabeto.indexOf(clave[j % clave.length]);
            let col = alfabeto.indexOf(char);
            resultado += matriz[row][col];
            j++;
        } else {
            resultado += char;
        }
    }
    console.log('Resultado cifrado: ' + resultado);
    return resultado;
}

// Descifrado Vigenère
function descifradoVigenere(texto, clave) {
    console.log(`Descifrando con Vigenère: "${texto}" con clave "${clave}"`);
    const alfabeto = mostrarAlfabeto();
    const matriz = generarMatrizVigenere();
    let resultado = '';

    for (let i = 0, j = 0; i < texto.length; i++) {
        let char = texto[i];

        if (char >= 'A' && char <= 'Z') {
            let row = alfabeto.indexOf(clave[j % clave.length]);
            let col = matriz[row].indexOf(char);
            resultado += alfabeto[col];
            j++;
        } else {
            resultado += char;
        }
    }
    console.log('Resultado descifrado: ' + resultado);
    return resultado;
}

// Exportar funciones para pruebas
module.exports = {
    cifradoCesar,
    descifradoCesar,
    cifradoVigenere,
    descifradoVigenere
};
