// Archivo: testCifradoCesarVigenere.js

const assert = require('assert');
const { cifradoCesar, descifradoCesar, cifradoVigenere, descifradoVigenere } = require('./cifradoCesarVigenere');

describe('Pruebas Cifrado César', function() {
    it('Cifrar César con desplazamiento 3', function() {
        assert.strictEqual(cifradoCesar('ABC', 3), 'DEF');
    });

    it('Descifrar César con desplazamiento 3', function() {
        assert.strictEqual(descifradoCesar('DEF', 3), 'ABC');
    });
});

describe('Pruebas Cifrado Vigenère', function() {
    it('Cifrar Vigenère con clave "KEY"', function() {
        assert.strictEqual(cifradoVigenere('HELLO', 'KEY'), 'RIJVS');
    });

    it('Descifrar Vigenère con clave "KEY"', function() {
        assert.strictEqual(descifradoVigenere('RIJVS', 'KEY'), 'HELLO');
    });
});
